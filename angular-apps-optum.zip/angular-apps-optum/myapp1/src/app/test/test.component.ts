import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-test',
  templateUrl: './test.component.html',
  styleUrls: ['./test.component.css']
})
export class TestComponent implements OnInit {
  status = true;
  displayList=true;
  message="Hello this is the test component";
  topics=["java","python","js"];
  employees= [{"id":1,"name":"gopi"},

  {"id":2,"name":"gopi2"},
  {"id":3,"name":"gopi3"},
  {"id":4,"name":"gopi4"}]
  constructor() { }

  ngOnInit() {
  }

  onClick(data){
    this.status=false;

    console.log(data);

  }

}
