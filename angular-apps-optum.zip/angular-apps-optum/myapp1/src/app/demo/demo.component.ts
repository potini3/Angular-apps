import { Component } from '@angular/core';

@Component ({
    selector:'demo-app',
    template:`
     <h1>Hello Class, my compoent 1</h1>
     <h2>{{message}}</h2> 
    `,
    styles:[]
})
export class DemoComponent{

message="My First Component"

}