import { Component, OnInit } from '@angular/core';
import { EmployeeService } from './employee.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  title = 'service-demo';
  public empList=[];
  constructor(private _empservice:EmployeeService) {}
  ngOnInit() {
    this._empservice.getEmployees().subscribe(data=>this.empList=data);
  }
}
