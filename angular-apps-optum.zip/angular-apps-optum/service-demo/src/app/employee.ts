import { Identifiers } from '@angular/compiler/src/render3/r3_identifiers';
export interface IEmployee {
    empId:number,
    name:string,
    city:string,
    salary:number
}